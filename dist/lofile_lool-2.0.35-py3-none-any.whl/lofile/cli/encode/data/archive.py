# lool-File Format # CLI Encoder # Archive-Data #

from lofile.cli.loolclitools import Selector, askpath, console_input, notepad_input, out


class Archive:

    def _data_archive(self):
        pass
