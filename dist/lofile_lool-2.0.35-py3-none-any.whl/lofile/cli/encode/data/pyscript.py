# lool-File Format # CLI Encoder # PyScript-Data #

from lofile.cli.loolclitools import Selector, askpath, console_input, notepad_input, out


class PyScript:

    def _data_pyscript(self):
        pass
